from app import app

# Vercel 使用這個入口點來部署 Flask 應用
# 實際代碼定義在 app.py 中

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080) 