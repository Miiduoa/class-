import os
import json
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
from dotenv import load_dotenv

# 加載環境變量
load_dotenv()

# 獲取MongoDB連接URI
def get_mongodb_uri():
    """從環境變量獲取MongoDB連接URI"""
    mongodb_uri = os.environ.get('MONGODB_URI')
    if not mongodb_uri:
        print("警告: 未設置MONGODB_URI環境變量，使用默認連接字符串")
        mongodb_uri = 'mongodb://localhost:27017/statistics_db'
    return mongodb_uri

# 獲取數據庫連接
def get_db_connection():
    """連接到MongoDB數據庫"""
    try:
        client = MongoClient(get_mongodb_uri())
        # 嘗試執行命令以驗證連接
        client.admin.command('ping')
        print("MongoDB連接成功")
        return client
    except ConnectionFailure as e:
        print(f"MongoDB連接失敗: {str(e)}")
        return None
    except Exception as e:
        print(f"MongoDB連接出錯: {str(e)}")
        return None

# 獲取講義集合
def get_lectures_collection():
    """獲取講義集合"""
    client = get_db_connection()
    if not client:
        return None
    
    try:
        db = client.get_database('statistics_db')
        collection = db.get_collection('lectures')
        return collection
    except Exception as e:
        print(f"獲取講義集合時出錯: {str(e)}")
        return None
    finally:
        # 不要在這裡關閉連接，因為返回的集合對象需要連接保持開啟
        pass

# 根據章節號獲取章節
def get_chapter_by_number(chapter_number):
    """根據章節號從MongoDB獲取章節數據"""
    collection = get_lectures_collection()
    if not collection:
        print(f"無法獲取章節 {chapter_number}：講義集合不可用")
        return None
    
    try:
        chapter = collection.find_one({'chapter_number': chapter_number})
        if chapter:
            # 移除MongoDB的_id字段，因為它不能序列化為JSON
            if '_id' in chapter:
                del chapter['_id']
            return chapter
        else:
            print(f"找不到章節 {chapter_number}")
            return None
    except Exception as e:
        print(f"獲取章節 {chapter_number} 時出錯: {str(e)}")
        return None

# 根據章節號和小節號獲取小節
def get_section_by_number(chapter_number, section_number):
    """根據章節號和小節號獲取特定小節的內容"""
    chapter = get_chapter_by_number(chapter_number)
    if not chapter:
        print(f"無法獲取小節 {chapter_number}.{section_number}：章節不存在")
        return None
    
    if 'sections' not in chapter:
        print(f"章節 {chapter_number} 中沒有小節數據")
        return None
    
    for section in chapter['sections']:
        if section.get('sectionNumber') == section_number:
            return section
    
    print(f"找不到小節 {chapter_number}.{section_number}")
    return None

# 加載講義內容 - 支持只傳入章節號的情況
def load_lecture_content(chapter_number, section_number=None):
    """
    加載講義內容，支持兩種模式：
    1. 只提供chapter_number：返回整個章節數據
    2. 同時提供chapter_number和section_number：返回特定小節數據
    """
    if section_number is None:
        # 只提供了章節號，返回整個章節數據
        return get_chapter_by_number(chapter_number)
    else:
        # 提供了章節號和小節號，返回特定小節數據
        return get_section_by_number(chapter_number, section_number)

# 獲取所有章節
def get_all_chapters():
    """獲取所有章節並按章節號排序"""
    collection = get_lectures_collection()
    if not collection:
        print("無法獲取章節列表：講義集合不可用")
        return []
    
    try:
        # 獲取所有章節並按章節號排序
        chapters = list(collection.find({}, {'_id': 0}).sort('chapter_number', 1))
        print(f"從MongoDB獲取到 {len(chapters)} 個章節")
        return chapters
    except Exception as e:
        print(f"獲取所有章節時出錯: {str(e)}")
        return [] 